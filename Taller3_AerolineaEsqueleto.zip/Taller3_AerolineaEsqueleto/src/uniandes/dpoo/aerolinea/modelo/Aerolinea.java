package uniandes.dpoo.aerolinea.modelo;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;
import uniandes.dpoo.aerolinea.exceptions.VueloSobrevendidoException;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifasTemporadaAlta;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifasTemporadaBaja;
import uniandes.dpoo.aerolinea.persistencia.CentralPersistencia;
import uniandes.dpoo.aerolinea.persistencia.IPersistenciaAerolinea;
import uniandes.dpoo.aerolinea.persistencia.IPersistenciaTiquetes;
import uniandes.dpoo.aerolinea.persistencia.TipoInvalidoException;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

/**
 * En esta clase se organizan todos los aspectos relacionados con una Aerolínea.
 * 
 * Por un lado, esta clase cumple un rol central como estructurador para todo el resto de elementos: directa o indirectamente, todos están contenidos y se pueden acceder a
 * través de la clase Aerolínea.
 * 
 * Por otro lado, esta clase implementa algunas funcionalidades adicionales a su rol como estructurador, para lo cual se apoya en las otras clases que hacen parte del
 * proyecto.
 */
public class Aerolinea
{
    /**
     * Una lista con los aviones de los que dispone la aerolínea
     */
    private List<Avion> aviones;

    /**
     * Un mapa con las rutas que cubre la aerolínea.
     * 
     * Las llaves del mapa son el código de la ruta, mientras que los valores son las rutas
     */
    private Map<String, Ruta> rutas;

    /**
     * Una lista de los vuelos programados por la aerolínea
     */
    private List<Vuelo> vuelos;

    /**
     * Un mapa con los clientes de la aerolínea.
     * 
     * Las llaves del mapa son los identificadores de los clientes, mientras que los valores son los clientes
     */
    private Map<String, Cliente> clientes;

    /**
     * Construye una nueva aerolínea con un nombre e inicializa todas las contenedoras con estructuras vacías
     */
    public Aerolinea( )
    {
        aviones = new LinkedList<Avion>( );
        rutas = new HashMap<String, Ruta>( );
        vuelos = new LinkedList<Vuelo>( );
        clientes = new HashMap<String, Cliente>( );
    }

    // ************************************************************************************
    //
    // Estos son los métodos que están relacionados con la manipulación básica de los atributos
    // de la aerolínea (consultar, agregar)
    //
    // ************************************************************************************

    /**
     * Agrega una nueva ruta a la aerolínea
     * @param ruta
     */
    public void agregarRuta( Ruta ruta )
    {
        this.rutas.put( ruta.getCodigoRuta( ), ruta );
    }

    /**
     * Agrega un nuevo avión a la aerolínea
     * @param avion
     */
    public void agregarAvion( Avion avion )
    {
        this.aviones.add( avion );
    }

    /**
     * Agrega un nuevo cliente a la aerolínea
     * @param cliente
     */
    public void agregarCliente( Cliente cliente )
    {
        this.clientes.put( cliente.getIdentificador( ), cliente );
    }

    /**
     * Verifica si ya existe un cliente con el identificador dado
     * @param identificadorCliente
     * @return Retorna true si ya existía un cliente con el identificador, independientemente de su tipo
     */
    public boolean existeCliente( String identificadorCliente )
    {
        return this.clientes.containsKey( identificadorCliente );
    }

    /**
     * Busca el cliente con el identificador dado
     * @param identificadorCliente
     * @return Retorna el cliente con el identificador, o null si no existía
     */
    public Cliente getCliente( String identificadorCliente )
    {
        return this.clientes.get( identificadorCliente );
    }

    /**
     * Retorna todos los aviones de la aerolínea
     * @return
     */
    public Collection<Avion> getAviones( )
    {
        return aviones;
    }

    /**
     * Retorna todas las rutas disponibles para la aerolínea
     * @return
     */
    public Collection<Ruta> getRutas( )
    {
        return rutas.values( );
    }

    /**
     * Retorna la ruta de la aerolínea que tiene el código dado
     * @param codigoRuta El código de la ruta buscada
     * @return La ruta con el código, o null si no existe una ruta con ese código
     */
    public Ruta getRuta( String codigoRuta )
    {
        return rutas.get( codigoRuta );
    }

    /**
     * Retorna todos los vuelos de la aerolínea
     * @return
     */
    public Collection<Vuelo> getVuelos( )
    {
        return vuelos;
    }

    /**
     * Busca un vuelo dado el código de la ruta y la fecha del vuelo.
     * @param codigoRuta
     * @param fechaVuelo
     * @return Retorna el vuelo que coincide con los parámetros dados. Si no lo encuentra, retorna null.
     */
    public Vuelo getVuelo( String codigoRuta, String fechaVuelo )
    {
        for( Vuelo vuelo : vuelos )
        {
            if( vuelo.getRuta( ).getCodigoRuta( ).equals( codigoRuta ) && vuelo.getFecha( ).equals( fechaVuelo ) )
                return vuelo;
        }
        return null;
    }

    /**
     * Retorna todos los clientes de la aerolínea
     * @return
     */
    public Collection<Cliente> getClientes( )
    {
        return clientes.values( );
    }

    /**
     * Retorna todos los tiquetes de la aerolínea, los cuales se recolectan vuelo por vuelo
     * @return
     */
    public Collection<Tiquete> getTiquetes( )
    {
        List<Tiquete> todosLosTiquetes = new LinkedList<Tiquete>( );
        for( Vuelo vuelo : vuelos )
            todosLosTiquetes.addAll( vuelo.getTiquetes( ) );
        return todosLosTiquetes;
    }

    // ************************************************************************************
    //
    // Estos son los métodos que están relacionados con la persistencia de la aerolínea
    //
    // ************************************************************************************

    /**
     * Carga toda la información de la aerolínea a partir de un archivo
     * @param archivo El nombre del archivo.
     * @param tipoArchivo El tipo del archivo. Puede ser CentralPersistencia.JSON o CentralPersistencia.PLAIN.
     * @throws TipoInvalidoException Se lanza esta excepción si se indica un tipo de archivo inválido
     * @throws IOException Lanza esta excepción si hay problemas leyendo el archivo
     * @throws InformacionInconsistenteException Lanza esta excepción si durante la carga del archivo se encuentra información que no es consistente
     */
    public void cargarAerolinea( String archivo, String tipoArchivo ) throws TipoInvalidoException, IOException, InformacionInconsistenteException
    {
        IPersistenciaAerolinea cargador = CentralPersistencia.getPersistenciaAerolinea( tipoArchivo );
        cargador.cargarAerolinea( archivo, this );
    }

    /**
     * Salva la información de la aerlínea en un archivo
     * @param archivo El nombre del archivo.
     * @param tipoArchivo El tipo del archivo. Puede ser CentralPersistencia.JSON o CentralPersistencia.PLAIN.
     * @throws TipoInvalidoException Se lanza esta excepción si se indica un tipo de archivo inválido
     * @throws IOException Lanza esta excepción si hay problemas escribiendo en el archivo
     */
    public void salvarAerolinea( String archivo, String tipoArchivo ) throws TipoInvalidoException, IOException
    {
        IPersistenciaAerolinea cargador = CentralPersistencia.getPersistenciaAerolinea( tipoArchivo );
        cargador.salvarAerolinea( archivo, this );
    }

    /**
     * Carga toda la información de sobre los clientes y tiquetes de una aerolínea a partir de un archivo
     * @param archivo El nombre del archivo.
     * @param tipoArchivo El tipo del archivo. Puede ser CentralPersistencia.JSON o CentralPersistencia.PLAIN.
     * @throws TipoInvalidoException Se lanza esta excepción si se indica un tipo de archivo inválido
     * @throws IOException Lanza esta excepción si hay problemas leyendo el archivo
     * @throws InformacionInconsistenteException Lanza esta excepción si durante la carga del archivo se encuentra información que no es consistente con la información de la
     *         aerolínea
     */
    public void cargarTiquetes( String archivo, String tipoArchivo ) throws TipoInvalidoException, IOException, InformacionInconsistenteException
    {
        IPersistenciaTiquetes cargador = CentralPersistencia.getPersistenciaTiquetes( tipoArchivo );
        cargador.cargarTiquetes( archivo, this );
    }

    /**
     * Salva la información de la aerlínea en un archivo
     * @param archivo El nombre del archivo.
     * @param tipoArchivo El tipo del archivo. Puede ser CentralPersistencia.JSON o CentralPersistencia.PLAIN.
     * @throws TipoInvalidoException Se lanza esta excepción si se indica un tipo de archivo inválido
     * @throws IOException Lanza esta excepción si hay problemas escribiendo en el archivo
     */
    public void salvarTiquetes( String archivo, String tipoArchivo ) throws TipoInvalidoException, IOException
    {
        IPersistenciaTiquetes cargador = CentralPersistencia.getPersistenciaTiquetes( tipoArchivo );
        cargador.salvarTiquetes( archivo, this );
    }

    // ************************************************************************************
    //
    // Estos son los métodos que están relacionados con funcionalidades interesantes de la aerolínea
    //
    // ************************************************************************************

    /**
     * Agrega un nuevo vuelo a la aerolínea, para que se realice en una cierta fecha, en una cierta ruta y con un cierto avión.
     * 
     * Este método debe verificar que el avión seleccionado no esté ya ocupado para otro vuelo en el mismo intervalo de tiempo del nuevo vuelo. No es necesario verificar que
     * se encuentre en el lugar correcto (origen del vuelo).
     * 
     * @param fecha La fecha en la que se realizará el vuelo
     * @param codigoRuta La ruta que cubirá el vuelo
     * @param nombreAvion El nombre del avión que realizará el vuelo
     * @throws Exception Lanza esta excepción si hay algún problema con los datos suministrados
     */
    public void programarVuelo( String fecha, String codigoRuta, String nombreAvion ) throws Exception
    {
        Ruta ruta = getRuta( codigoRuta );
        if( ruta == null )
            throw new Exception( "No existe una ruta con el código " + codigoRuta );

        Avion avion = null;
        for( Avion unAvion : aviones )
        {
            if( unAvion.getNombre( ).equals( nombreAvion ) )
            {
                avion = unAvion;
                break;
            }
        }
        if( avion == null )
            throw new Exception( "No existe un avión con el nombre " + nombreAvion );

        // Calcular el intervalo de tiempo (en minutos, contados desde una referencia común) que ocupará el nuevo vuelo
        int inicioNuevoVuelo = calcularInstanteInicioVuelo( fecha, ruta );
        int finNuevoVuelo = inicioNuevoVuelo + ruta.getDuracion( );

        for( Vuelo vueloExistente : vuelos )
        {
            if( vueloExistente.getAvion( ) == avion )
            {
                Ruta rutaExistente = vueloExistente.getRuta( );
                int inicioExistente = calcularInstanteInicioVuelo( vueloExistente.getFecha( ), rutaExistente );
                int finExistente = inicioExistente + rutaExistente.getDuracion( );

                boolean seSobreponen = inicioNuevoVuelo < finExistente && inicioExistente < finNuevoVuelo;
                if( seSobreponen )
                    throw new Exception( "El avión " + nombreAvion + " ya está ocupado en ese intervalo de tiempo" );
            }
        }

        Vuelo nuevoVuelo = new Vuelo( ruta, fecha, avion );
        vuelos.add( nuevoVuelo );
    }

    /**
     * Calcula, en minutos, un instante absoluto de inicio para un vuelo, a partir de su fecha (YYYY-MM-DD) y la hora de salida de su ruta.
     * 
     * Este valor sólo tiene sentido para compararlo con otros calculados de la misma forma (por ejemplo, para verificar si dos vuelos se sobreponen en el tiempo).
     * @param fecha La fecha del vuelo, expresada como YYYY-MM-DD
     * @param ruta La ruta que cubre el vuelo
     * @return Un número de minutos, contados desde una referencia común arbitraria
     */
    private int calcularInstanteInicioVuelo( String fecha, Ruta ruta )
    {
        String[ ] partesFecha = fecha.split( "-" );
        int anio = Integer.parseInt( partesFecha[ 0 ] );
        int mes = Integer.parseInt( partesFecha[ 1 ] );
        int dia = Integer.parseInt( partesFecha[ 2 ] );

        // Se usa una aproximación de 31 días por mes y 366 días por año: es suficiente para comparar intervalos relativos entre sí
        long diasTotales = ( ( long )anio * 366 ) + ( mes * 31 ) + dia;
        long minutosDelDia = Ruta.getHoras( ruta.getHoraSalida( ) ) * 60 + Ruta.getMinutos( ruta.getHoraSalida( ) );

        return ( int )( diasTotales * 24 * 60 + minutosDelDia );
    }

    /**
     * Vende una cierta cantidad de tiquetes para un vuelo, verificando que la información sea correcta.
     * 
     * Los tiquetes deben quedar asociados al vuelo y al cliente.
     * 
     * Según la fecha del vuelo, se deben usar las tarifas de temporada baja (enero a mayo y septiembre a noviembre) o las de temporada alta (el resto del año).
     * 
     * @param identificadorCliente El identificador del cliente al cual se le venden los tiquetes
     * @param fecha La fecha en la que se realiza el vuelo para el que se van a vender los tiquetes
     * @param codigoRuta El código de la ruta para el que se van a vender los tiquetes
     * @param cantidad La cantidad de tiquetes que se quieren comprar
     * @return El valor total de los tiquetes vendidos
     * @throws VueloSobrevendidoException Se lanza esta excepción si no hay suficiente espacio en el vuelo para todos los pasajeros
     * @throws Exception Se lanza esta excepción para indicar que no se pudieron vender los tiquetes por algún otro motivo
     */
    public int venderTiquetes( String identificadorCliente, String fecha, String codigoRuta, int cantidad ) throws VueloSobrevendidoException, Exception
    {
        Cliente cliente = getCliente( identificadorCliente );
        if( cliente == null )
            throw new Exception( "No existe un cliente con el identificador " + identificadorCliente );

        Vuelo vuelo = getVuelo( codigoRuta, fecha );
        if( vuelo == null )
            throw new Exception( "No existe un vuelo para la ruta " + codigoRuta + " en la fecha " + fecha );

        CalculadoraTarifas calculadora = esTemporadaBaja( fecha ) ? new CalculadoraTarifasTemporadaBaja( ) : new CalculadoraTarifasTemporadaAlta( );

        return vuelo.venderTiquetes( cliente, calculadora, cantidad );
    }

    /**
     * Determina si una fecha dada (en formato YYYY-MM-DD) corresponde a temporada baja (enero a mayo y septiembre a noviembre) o a temporada alta (el resto del año)
     * @param fecha La fecha que se quiere consultar
     * @return true si la fecha corresponde a temporada baja
     */
    private boolean esTemporadaBaja( String fecha )
    {
        int mes = Integer.parseInt( fecha.split( "-" )[ 1 ] );
        return ( mes >= 1 && mes <= 5 ) || ( mes >= 9 && mes <= 11 );
    }

    /**
     * Registra que un cierto vuelo fue realizado
     * @param fecha La fecha del vuelo
     * @param codigoRuta El código de la ruta que recorrió el vuelo
     */
    public void registrarVueloRealizado( String fecha, String codigoRuta )
    {
        Vuelo vuelo = getVuelo( codigoRuta, fecha );
        if( vuelo == null )
            return;

        // Se recolectan primero los clientes distintos que compraron tiquetes para este vuelo, para no procesar dos veces al mismo cliente
        Set<Cliente> clientesDelVuelo = new HashSet<Cliente>( );
        for( Tiquete tiquete : vuelo.getTiquetes( ) )
            clientesDelVuelo.add( tiquete.getCliente( ) );

        for( Cliente cliente : clientesDelVuelo )
            cliente.usarTiquetes( vuelo );
    }

    /**
     * Calcula cuánto valen los tiquetes que ya compró un cliente dado y que todavía no ha utilizado
     * @param identificadorCliente El identificador del cliente
     * @return La suma de lo que pagó el cliente por los tiquetes sin usar
     */
    public String consultarSaldoPendienteCliente( String identificadorCliente )
    {
        Cliente cliente = getCliente( identificadorCliente );
        if( cliente == null )
            return "";

        return String.valueOf( cliente.calcularValorTotalTiquetes( ) );
    }

}
